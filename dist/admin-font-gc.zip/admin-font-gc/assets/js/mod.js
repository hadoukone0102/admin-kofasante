export class myModule {
    constructor(){}

    goToConsole() {
        console.log("je suis dans le monde");
    }
}